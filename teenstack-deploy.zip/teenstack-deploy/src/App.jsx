import React, { useState, useEffect, useCallback } from 'react';

const SUPABASE_URL = 'https://dwtlasxwuvymcwmqgxom.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR3dGxhc3h3dXZ5bWN3bXFneG9tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI3NTE2OTMsImV4cCI6MjA5ODMyNzY5M30.Bl2krH7EIjlVFpUW6vrmeGkmX51005CL0d4ciSZW03U';

// ============ MINIMAL SUPABASE REST CLIENT (no SDK needed) ============
const sb = {
  headers(token) {
    return {
      'apikey': SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${token || SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    };
  },
  async fetchWithTimeout(url, options, ms = 12000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), ms);
    try {
      const res = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(timer);
      return res;
    } catch (err) {
      clearTimeout(timer);
      if (err.name === 'AbortError') throw new Error('Сервер не отвечает. Проверь интернет и попробуй ещё раз.');
      throw new Error('Сетевая ошибка. Проверь подключение к интернету.');
    }
  },
  async signUp(email, password, username) {
    const res = await this.fetchWithTimeout(`${SUPABASE_URL}/auth/v1/signup`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify({ email, password, data: { username, display_name: username } }),
    });
    let data;
    try { data = await res.json(); } catch { data = {}; }
    if (!res.ok) throw new Error(data.msg || data.error_description || data.message || `Ошибка регистрации (код ${res.status})`);
    return data;
  },
  async signIn(email, password) {
    const res = await this.fetchWithTimeout(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify({ email, password }),
    });
    let data;
    try { data = await res.json(); } catch { data = {}; }
    if (!res.ok) throw new Error(data.msg || data.error_description || data.message || `Неверный email или пароль (код ${res.status})`);
    return data;
  },
  async signOut(token) {
    await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
      method: 'POST',
      headers: this.headers(token),
    });
  },
  async getUser(token) {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: this.headers(token),
    });
    if (!res.ok) throw new Error('Сессия истекла');
    return res.json();
  },
  async select(table, token, query = '') {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${query}`, {
      headers: this.headers(token),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Ошибка загрузки данных');
    return data;
  },
  async insert(table, token, body) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
      method: 'POST',
      headers: { ...this.headers(token), 'Prefer': 'return=representation' },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Ошибка сохранения');
    return data;
  },
  async update(table, token, query, body) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${query}`, {
      method: 'PATCH',
      headers: { ...this.headers(token), 'Prefer': 'return=representation' },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Ошибка обновления');
    return data;
  },
  async remove(table, token, query) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${query}`, {
      method: 'DELETE',
      headers: this.headers(token),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.message || 'Ошибка удаления');
    }
    return true;
  },
};

// ============ TEMPLATES META ============
const TEMPLATES = [
  { id: 'art-shop', emoji: '🎨', name: 'Мини-магазин арта', desc: 'Витрина, корзина, оплата', color: '#7C3AED' },
  { id: 'habit-tracker', emoji: '📅', name: 'Трекер привычек', desc: 'Подписка, прогресс', color: '#AAFF00' },
  { id: 'portfolio', emoji: '💼', name: 'Портфолио фрилансера', desc: 'Работы, прайс, заявки', color: '#FF6432' },
  { id: 'schedule-gen', emoji: '🧮', name: 'Генератор расписания', desc: 'Инструмент с оплатой', color: '#6496FF' },
  { id: 'mini-course', emoji: '🎓', name: 'Мини-курс', desc: 'Уроки, прогресс, оплата', color: '#FFC832' },
  { id: 'support-me', emoji: '💖', name: 'Страница донатов', desc: 'Boosty + YooKassa', color: '#32C8C8' },
];

function templateMeta(id) {
  return TEMPLATES.find(t => t.id === id) || TEMPLATES[0];
}

function slugify(str) {
  const translit = { а:'a',б:'b',в:'v',г:'g',д:'d',е:'e',ё:'e',ж:'zh',з:'z',и:'i',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'h',ц:'c',ч:'ch',ш:'sh',щ:'sch',ъ:'',ы:'y',ь:'',э:'e',ю:'yu',я:'ya' };
  return str.toLowerCase().split('').map(c => translit[c] !== undefined ? translit[c] : c).join('')
    .replace(/[^a-z0-9\s-]/g, '').trim().replace(/\s+/g, '-').replace(/-+/g, '-').slice(0, 40);
}

function formatPrice(cents) {
  return (cents / 100).toLocaleString('ru-RU');
}

// ============ TOAST SYSTEM ============
function useToasts() {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((message, type = 'info') => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, message, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3500);
  }, []);
  return { toasts, push };
}

function ToastStack({ toasts }) {
  return (
    <div style={S.toastStack}>
      {toasts.map(t => (
        <div key={t.id} style={{ ...S.toast, borderColor: t.type === 'error' ? '#FF5F57' : t.type === 'success' ? '#AAFF00' : '#7C3AED' }}>
          {t.message}
        </div>
      ))}
    </div>
  );
}

// ============ STYLES ============
const S = {
  app: { minHeight: '100vh', background: '#0D0D12', color: '#E8E8F0', fontFamily: "'Inter', sans-serif", fontSize: 15 },
  nav: { position: 'sticky', top: 0, zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', background: 'rgba(13,13,18,0.92)', backdropFilter: 'blur(16px)', borderBottom: '1px solid #2A2A38' },
  logo: { fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 20, color: '#F8F8FF', cursor: 'pointer', letterSpacing: -0.5 },
  logoAccent: { color: '#AAFF00' },
  navRight: { display: 'flex', gap: 10, alignItems: 'center' },
  btnPrimary: { background: '#AAFF00', color: '#0D0D12', border: 'none', padding: '10px 18px', borderRadius: 10, fontWeight: 700, fontSize: 14, cursor: 'pointer' },
  btnGhost: { background: 'transparent', color: '#8888A0', border: '1px solid #2A2A38', padding: '10px 18px', borderRadius: 10, fontWeight: 600, fontSize: 14, cursor: 'pointer' },
  btnDanger: { background: 'transparent', color: '#FF5F57', border: '1px solid #FF5F5740', padding: '10px 18px', borderRadius: 10, fontWeight: 600, fontSize: 14, cursor: 'pointer' },
  container: { maxWidth: 1100, margin: '0 auto', padding: '40px 20px' },
  h1: { fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 32, letterSpacing: -1, color: '#F8F8FF', marginBottom: 8 },
  sub: { color: '#8888A0', fontSize: 15, marginBottom: 32 },
  card: { background: '#1A1A24', border: '1px solid #2A2A38', borderRadius: 16, padding: 24 },
  input: { width: '100%', background: '#0D0D12', border: '1px solid #2A2A38', borderRadius: 10, padding: '13px 14px', color: '#F8F8FF', fontSize: 15, fontFamily: 'inherit', outline: 'none', marginBottom: 14, boxSizing: 'border-box' },
  label: { fontSize: 13, fontWeight: 600, color: '#8888A0', marginBottom: 6, display: 'block' },
  authWrap: { display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '90vh', padding: 20 },
  authCard: { width: '100%', maxWidth: 400, background: '#1A1A24', border: '1px solid #2A2A38', borderRadius: 20, padding: 32 },
  toastStack: { position: 'fixed', top: 80, right: 20, left: 20, zIndex: 200, display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end', pointerEvents: 'none' },
  toast: { background: '#1A1A24', border: '1px solid', borderRadius: 10, padding: '12px 16px', fontSize: 14, color: '#F8F8FF', maxWidth: 320, boxShadow: '0 8px 24px rgba(0,0,0,0.4)' },
  grid3: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 },
  spinner: { width: 18, height: 18, border: '2.5px solid #2A2A38', borderTopColor: '#AAFF00', borderRadius: '50%', animation: 'spin 0.7s linear infinite', display: 'inline-block' },
};

// ============ LOADING SPINNER ============
function Spinner() {
  return <span style={S.spinner} />;
}

// ============ LANDING ============
function Landing({ onAuth }) {
  return (
    <div style={S.app}>
      <nav style={S.nav}>
        <div style={S.logo}>Teen<span style={S.logoAccent}>Stack</span></div>
        <div style={S.navRight}>
          <button style={S.btnGhost} onClick={() => onAuth('signin')}>Войти</button>
          <button style={S.btnPrimary} onClick={() => onAuth('signup')}>Начать бесплатно</button>
        </div>
      </nav>
      <div style={{ ...S.container, textAlign: 'center', paddingTop: 80, paddingBottom: 80 }}>
        <div style={{ display: 'inline-block', background: 'rgba(124,58,237,0.15)', border: '1px solid rgba(124,58,237,0.4)', borderRadius: 100, padding: '6px 16px', fontSize: 13, fontWeight: 600, color: '#9D5FF0', marginBottom: 24 }}>
          ✦ Бета-доступ открыт
        </div>
        <h1 style={{ ...S.h1, fontSize: 'clamp(32px, 6vw, 56px)', maxWidth: 700, margin: '0 auto 16px' }}>
          Запусти свой первый <span style={{ color: '#AAFF00' }}>настоящий</span> продукт
        </h1>
        <p style={{ ...S.sub, fontSize: 18, maxWidth: 480, margin: '0 auto 32px' }}>
          Конструктор мини-SaaS для подростков и молодых фрилансеров. Реальная база данных, реальная авторизация, реальные проекты.
        </p>
        <button style={{ ...S.btnPrimary, fontSize: 16, padding: '15px 32px' }} onClick={() => onAuth('signup')}>
          Создать аккаунт →
        </button>
      </div>
      <div style={{ ...S.container, paddingTop: 0 }}>
        <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 24, fontWeight: 700, marginBottom: 24, textAlign: 'center' }}>6 готовых шаблонов</h2>
        <div style={S.grid3}>
          {TEMPLATES.map(t => (
            <div key={t.id} style={{ ...S.card, textAlign: 'center' }}>
              <div style={{ fontSize: 32, marginBottom: 10 }}>{t.emoji}</div>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>{t.name}</div>
              <div style={{ fontSize: 13, color: '#8888A0' }}>{t.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============ AUTH SCREEN ============
function AuthScreen({ mode, setMode, onSuccess, push }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const isSignup = mode === 'signup';

  async function submit(e) {
    e.preventDefault();
    setError('');
    if (!email || !password) { setError('Заполни email и пароль'); return; }
    if (isSignup && password.length < 6) { setError('Пароль должен быть от 6 символов'); return; }
    if (isSignup && !username.trim()) { setError('Придумай никнейм'); return; }

    setLoading(true);
    try {
      if (isSignup) {
        const data = await sb.signUp(email, password, slugify(username) || 'user');
        if (data && data.access_token) {
          onSuccess(data.access_token, data.user);
          push('Аккаунт создан! Добро пожаловать 🎉', 'success');
        } else if (data && data.id && !data.access_token) {
          // Email confirmation required by project settings
          setError('Аккаунт создан, но включено подтверждение по email. Письмо может не дойти — попроси меня отключить это требование в Supabase, либо проверь папку "Спам".');
          push('Нужно подтверждение email — см. подсказку ниже', 'info');
        } else {
          setError('Сервер вернул непонятный ответ. Попробуй ещё раз через пару секунд.');
        }
      } else {
        const data = await sb.signIn(email, password);
        onSuccess(data.access_token, data.user);
        push('С возвращением!', 'success');
      }
    } catch (err) {
      setError(err.message || 'Что-то пошло не так. Попробуй ещё раз.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={S.app}>
      <nav style={S.nav}>
        <div style={S.logo} onClick={() => setMode('landing')}>Teen<span style={S.logoAccent}>Stack</span></div>
      </nav>
      <div style={S.authWrap}>
        <form style={S.authCard} onSubmit={submit}>
          <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 24, marginBottom: 6 }}>
            {isSignup ? 'Создать аккаунт' : 'Вход'}
          </h2>
          <p style={{ color: '#8888A0', fontSize: 14, marginBottom: 24 }}>
            {isSignup ? 'Это бесплатно и займёт 30 секунд' : 'Рады видеть снова'}
          </p>

          {isSignup && (
            <>
              <label style={S.label}>Никнейм</label>
              <input style={S.input} value={username} onChange={e => setUsername(e.target.value)} placeholder="alex_creates" autoCapitalize="off" />
            </>
          )}

          <label style={S.label}>Email</label>
          <input style={S.input} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" autoCapitalize="off" />

          <label style={S.label}>Пароль</label>
          <input style={S.input} type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" />

          {error && <div style={{ background: 'rgba(255,95,87,0.1)', border: '1px solid rgba(255,95,87,0.3)', color: '#FF8580', borderRadius: 10, padding: '10px 14px', fontSize: 13, marginBottom: 14 }}>{error}</div>}

          <button type="submit" style={{ ...S.btnPrimary, width: '100%', padding: '14px', fontSize: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }} disabled={loading}>
            {loading ? <Spinner /> : (isSignup ? 'Создать аккаунт' : 'Войти')}
          </button>

          <div style={{ textAlign: 'center', marginTop: 18, fontSize: 14, color: '#8888A0' }}>
            {isSignup ? 'Уже есть аккаунт?' : 'Нет аккаунта?'}{' '}
            <span style={{ color: '#AAFF00', cursor: 'pointer', fontWeight: 600 }} onClick={() => { setMode(isSignup ? 'signin' : 'signup'); setError(''); }}>
              {isSignup ? 'Войти' : 'Зарегистрироваться'}
            </span>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============ DASHBOARD ============
function Dashboard({ token, user, profile, onLogout, onOpenProject, push, refreshProfile }) {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  const loadProjects = useCallback(async () => {
    setLoading(true);
    try {
      const data = await sb.select('projects', token, `owner_id=eq.${user.id}&order=created_at.desc`);
      setProjects(data);
    } catch (err) {
      push(err.message, 'error');
    } finally {
      setLoading(false);
    }
  }, [token, user.id, push]);

  useEffect(() => { loadProjects(); }, [loadProjects]);

  async function createProject(templateId) {
    if (profile.plan === 'free' && projects.length >= 1) {
      push('На бесплатном плане доступен только 1 проект. Скоро будет апгрейд до Про!', 'error');
      return;
    }
    setCreating(true);
    try {
      const meta = templateMeta(templateId);
      const baseSlug = slugify(profile.username) + '-' + templateId;
      const slug = baseSlug + '-' + Math.random().toString(36).slice(2, 6);
      const data = await sb.insert('projects', token, {
        owner_id: user.id,
        slug,
        template: templateId,
        title: meta.name,
        subtitle: meta.desc,
        data: {},
        is_published: false,
      });
      push('Проект создан!', 'success');
      setProjects(p => [data[0], ...p]);
      onOpenProject(data[0]);
    } catch (err) {
      push(err.message.includes('Free plan limit') ? 'Лимит бесплатного плана: 1 проект' : err.message, 'error');
    } finally {
      setCreating(false);
    }
  }

  async function deleteProject(id) {
    if (!window.confirm) {} // no-op guard for SSR safety
    try {
      await sb.remove('projects', token, `id=eq.${id}`);
      setProjects(p => p.filter(x => x.id !== id));
      push('Проект удалён', 'info');
    } catch (err) {
      push(err.message, 'error');
    }
  }

  return (
    <div style={S.app}>
      <nav style={S.nav}>
        <div style={S.logo}>Teen<span style={S.logoAccent}>Stack</span></div>
        <div style={S.navRight}>
          <span style={{ fontSize: 13, color: '#8888A0', display: window.innerWidth > 500 ? 'inline' : 'none' }}>@{profile?.username}</span>
          <button style={S.btnGhost} onClick={onLogout}>Выйти</button>
        </div>
      </nav>
      <div style={S.container}>
        <h1 style={S.h1}>Мои проекты</h1>
        <p style={S.sub}>
          План: <strong style={{ color: profile.plan === 'free' ? '#8888A0' : '#AAFF00' }}>{profile.plan === 'free' ? 'Бесплатный (1 проект)' : profile.plan === 'pro' ? 'Про' : 'Команда'}</strong>
          {' · '}{projects.length} {projects.length === 1 ? 'проект' : 'проектов'}
        </p>

        {loading ? (
          <div style={{ padding: 40, textAlign: 'center', color: '#8888A0' }}><Spinner /> Загрузка...</div>
        ) : (
          <>
            {projects.length > 0 && (
              <div style={{ ...S.grid3, marginBottom: 40 }}>
                {projects.map(p => {
                  const meta = templateMeta(p.template);
                  return (
                    <div key={p.id} style={S.card}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                        <div style={{ fontSize: 24 }}>{meta.emoji}</div>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: 700, fontSize: 15 }}>{p.title}</div>
                          <div style={{ fontSize: 12, color: '#8888A0' }}>/{p.slug}</div>
                        </div>
                        <div style={{
                          fontSize: 11, fontWeight: 700, padding: '3px 9px', borderRadius: 100,
                          background: p.is_published ? 'rgba(170,255,0,0.12)' : 'rgba(136,136,160,0.12)',
                          color: p.is_published ? '#AAFF00' : '#8888A0',
                        }}>
                          {p.is_published ? 'ОПУБЛИКОВАН' : 'ЧЕРНОВИК'}
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <button style={{ ...S.btnPrimary, flex: 1, padding: '9px' }} onClick={() => onOpenProject(p)}>Редактировать</button>
                        <button style={{ ...S.btnDanger, padding: '9px 14px' }} onClick={() => deleteProject(p.id)}>✕</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 20, marginBottom: 16 }}>
              {projects.length > 0 ? 'Создать ещё один проект' : 'Выбери шаблон для старта'}
            </h2>
            <div style={S.grid3}>
              {TEMPLATES.map(t => (
                <div key={t.id} style={{ ...S.card, cursor: creating ? 'default' : 'pointer', opacity: creating ? 0.6 : 1, transition: 'transform .15s' }}
                  onClick={() => !creating && createProject(t.id)}>
                  <div style={{ fontSize: 28, marginBottom: 10 }}>{t.emoji}</div>
                  <div style={{ fontWeight: 700, marginBottom: 4 }}>{t.name}</div>
                  <div style={{ fontSize: 13, color: '#8888A0', marginBottom: 14 }}>{t.desc}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: t.color }}>+ Создать →</div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ============ PROJECT EDITOR ============
function ProjectEditor({ token, project, onBack, push, onUpdated }) {
  const meta = templateMeta(project.template);
  const [title, setTitle] = useState(project.title);
  const [subtitle, setSubtitle] = useState(project.subtitle || '');
  const [accentColor, setAccentColor] = useState(project.data?.accentColor || meta.color);
  const [products, setProducts] = useState([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [isPublished, setIsPublished] = useState(project.is_published);
  const [tab, setTab] = useState('content');

  const needsProducts = ['art-shop', 'mini-course'].includes(project.template);

  const loadProducts = useCallback(async () => {
    if (!needsProducts) { setLoadingProducts(false); return; }
    try {
      const data = await sb.select('products', token, `project_id=eq.${project.id}&order=created_at.asc`);
      setProducts(data);
    } catch (err) {
      push(err.message, 'error');
    } finally {
      setLoadingProducts(false);
    }
  }, [token, project.id, needsProducts, push]);

  useEffect(() => { loadProducts(); }, [loadProducts]);

  async function saveContent() {
    setSaving(true);
    try {
      const data = await sb.update('projects', token, `id=eq.${project.id}`, {
        title, subtitle, data: { ...project.data, accentColor },
      });
      onUpdated(data[0]);
      push('Сохранено', 'success');
    } catch (err) {
      push(err.message, 'error');
    } finally {
      setSaving(false);
    }
  }

  async function togglePublish() {
    setPublishing(true);
    try {
      const next = !isPublished;
      const data = await sb.update('projects', token, `id=eq.${project.id}`, { is_published: next });
      setIsPublished(next);
      onUpdated(data[0]);
      push(next ? 'Проект опубликован! 🚀' : 'Проект снят с публикации', next ? 'success' : 'info');
    } catch (err) {
      push(err.message, 'error');
    } finally {
      setPublishing(false);
    }
  }

  async function addProduct(e) {
    e.preventDefault();
    const form = e.target;
    const ptitle = form.ptitle.value.trim();
    const price = parseFloat(form.price.value);
    if (!ptitle || !price || price <= 0) { push('Заполни название и цену', 'error'); return; }
    try {
      const data = await sb.insert('products', token, {
        project_id: project.id,
        title: ptitle,
        description: form.pdesc.value.trim(),
        price_cents: Math.round(price * 100),
      });
      setProducts(p => [...p, data[0]]);
      form.reset();
      push('Товар добавлен', 'success');
    } catch (err) {
      push(err.message, 'error');
    }
  }

  async function deleteProduct(id) {
    try {
      await sb.remove('products', token, `id=eq.${id}`);
      setProducts(p => p.filter(x => x.id !== id));
      push('Товар удалён', 'info');
    } catch (err) {
      push(err.message, 'error');
    }
  }

  const publicUrl = `teenstack.app/${project.slug}`;

  return (
    <div style={S.app}>
      <nav style={S.nav}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <span style={{ cursor: 'pointer', color: '#8888A0', fontSize: 14 }} onClick={onBack}>← Назад</span>
          <div style={S.logo}>Teen<span style={S.logoAccent}>Stack</span></div>
        </div>
        <div style={S.navRight}>
          <button style={isPublished ? S.btnDanger : S.btnPrimary} onClick={togglePublish} disabled={publishing}>
            {publishing ? <Spinner /> : (isPublished ? 'Снять с публикации' : 'Опубликовать')}
          </button>
        </div>
      </nav>

      <div style={S.container}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <span style={{ fontSize: 24 }}>{meta.emoji}</span>
          <h1 style={{ ...S.h1, marginBottom: 0 }}>{meta.name}</h1>
        </div>
        <p style={S.sub}>
          {isPublished ? <span style={{ color: '#AAFF00' }}>● Опубликован на {publicUrl}</span> : <span>Черновик — пока не виден другим</span>}
        </p>

        <div style={{ display: 'flex', gap: 8, marginBottom: 24, borderBottom: '1px solid #2A2A38' }}>
          {['content', needsProducts ? 'products' : null, 'preview'].filter(Boolean).map(t => (
            <div key={t} onClick={() => setTab(t)} style={{
              padding: '10px 18px', cursor: 'pointer', fontSize: 14, fontWeight: 600,
              color: tab === t ? '#F8F8FF' : '#8888A0',
              borderBottom: tab === t ? '2px solid #AAFF00' : '2px solid transparent',
            }}>
              {t === 'content' ? 'Контент' : t === 'products' ? `Товары (${products.length})` : 'Предпросмотр'}
            </div>
          ))}
        </div>

        {tab === 'content' && (
          <div style={{ ...S.card, maxWidth: 520 }}>
            <label style={S.label}>Название проекта</label>
            <input style={S.input} value={title} onChange={e => setTitle(e.target.value)} maxLength={60} />

            <label style={S.label}>Подзаголовок</label>
            <input style={S.input} value={subtitle} onChange={e => setSubtitle(e.target.value)} maxLength={120} />

            <label style={S.label}>Акцентный цвет</label>
            <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
              {['#7C3AED', '#AAFF00', '#FF6432', '#6496FF', '#FFC832', '#32C8C8'].map(c => (
                <div key={c} onClick={() => setAccentColor(c)} style={{
                  width: 34, height: 34, borderRadius: 10, background: c, cursor: 'pointer',
                  border: accentColor === c ? '2.5px solid #F8F8FF' : '2.5px solid transparent',
                }} />
              ))}
            </div>

            <button style={{ ...S.btnPrimary, padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 8 }} onClick={saveContent} disabled={saving}>
              {saving ? <Spinner /> : 'Сохранить изменения'}
            </button>
          </div>
        )}

        {tab === 'products' && needsProducts && (
          <div>
            <div style={{ ...S.card, maxWidth: 520, marginBottom: 24 }}>
              <h3 style={{ fontWeight: 700, marginBottom: 14, fontSize: 16 }}>Добавить товар</h3>
              <form onSubmit={addProduct}>
                <label style={S.label}>Название</label>
                <input name="ptitle" style={S.input} placeholder="Стикерпак «Котики»" maxLength={80} />
                <label style={S.label}>Описание</label>
                <input name="pdesc" style={S.input} placeholder="10 стикеров в высоком качестве" maxLength={200} />
                <label style={S.label}>Цена, ₽</label>
                <input name="price" type="number" min="1" step="1" style={S.input} placeholder="299" />
                <button type="submit" style={{ ...S.btnPrimary, padding: '11px 20px' }}>+ Добавить товар</button>
              </form>
            </div>

            {loadingProducts ? (
              <div style={{ color: '#8888A0' }}><Spinner /> Загрузка товаров...</div>
            ) : products.length === 0 ? (
              <p style={{ color: '#8888A0' }}>Пока нет товаров. Добавь первый выше ↑</p>
            ) : (
              <div style={S.grid3}>
                {products.map(p => (
                  <div key={p.id} style={S.card}>
                    <div style={{ fontWeight: 700, marginBottom: 4 }}>{p.title}</div>
                    {p.description && <div style={{ fontSize: 13, color: '#8888A0', marginBottom: 10 }}>{p.description}</div>}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div style={{ fontWeight: 800, color: accentColor, fontSize: 16 }}>{formatPrice(p.price_cents)} ₽</div>
                      <button style={{ ...S.btnDanger, padding: '6px 12px', fontSize: 12 }} onClick={() => deleteProduct(p.id)}>Удалить</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'preview' && (
          <PublicPreview project={{ ...project, title, subtitle, data: { accentColor } }} products={products} />
        )}
      </div>
    </div>
  );
}

// ============ PUBLIC PREVIEW (matches what visitors would see) ============
function PublicPreview({ project, products }) {
  const meta = templateMeta(project.template);
  const accent = project.data?.accentColor || meta.color;
  return (
    <div style={{ background: '#13131A', border: '1px solid #2A2A38', borderRadius: 16, padding: 32, maxWidth: 600 }}>
      <div style={{ fontSize: 36, marginBottom: 12 }}>{meta.emoji}</div>
      <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 26, fontWeight: 800, marginBottom: 8, color: '#F8F8FF' }}>{project.title}</h2>
      <p style={{ color: '#8888A0', marginBottom: 24 }}>{project.subtitle}</p>

      {['art-shop', 'mini-course'].includes(project.template) && (
        <div style={{ display: 'grid', gap: 10 }}>
          {products.length === 0 ? (
            <p style={{ color: '#8888A0', fontSize: 14 }}>Товары появятся здесь после добавления.</p>
          ) : products.map(p => (
            <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#0D0D12', padding: '14px 16px', borderRadius: 10, border: '1px solid #2A2A38' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 14 }}>{p.title}</div>
                <div style={{ fontSize: 12, color: '#8888A0' }}>{p.description}</div>
              </div>
              <button style={{ background: accent, color: '#0D0D12', border: 'none', padding: '8px 16px', borderRadius: 8, fontWeight: 700, fontSize: 13 }}>
                {formatPrice(p.price_cents)} ₽
              </button>
            </div>
          ))}
        </div>
      )}

      {!['art-shop', 'mini-course'].includes(project.template) && (
        <button style={{ background: accent, color: '#0D0D12', border: 'none', padding: '12px 24px', borderRadius: 10, fontWeight: 700 }}>
          {project.template === 'support-me' ? 'Поддержать →' : project.template === 'habit-tracker' ? 'Начать →' : 'Узнать больше →'}
        </button>
      )}
    </div>
  );
}

// ============ ROOT APP ============
export default function App() {
  const [screen, setScreen] = useState('landing'); // landing | signin | signup | dashboard | editor
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [activeProject, setActiveProject] = useState(null);
  const [bootLoading, setBootLoading] = useState(true);
  const { toasts, push } = useToasts();

  // Restore session from localStorage on real website (this works outside the chat artifact sandbox)
  useEffect(() => {
    const saved = localStorage.getItem('teenstack_session');
    if (saved) {
      try {
        const { token: tok, user: u } = JSON.parse(saved);
        sb.getUser(tok).then(async (freshUser) => {
          setToken(tok);
          setUser(freshUser);
          await loadProfile(freshUser.id, tok);
          setScreen('dashboard');
        }).catch(() => {
          localStorage.removeItem('teenstack_session');
        }).finally(() => setBootLoading(false));
      } catch {
        localStorage.removeItem('teenstack_session');
        setBootLoading(false);
      }
    } else {
      setBootLoading(false);
    }
  }, []);

  async function loadProfile(uid, tok) {
    try {
      const rows = await sb.select('profiles', tok, `id=eq.${uid}`);
      if (rows[0]) setProfile(rows[0]);
    } catch (err) {
      push('Не удалось загрузить профиль', 'error');
    }
  }

  async function handleAuthSuccess(tok, u) {
    setToken(tok);
    setUser(u);
    localStorage.setItem('teenstack_session', JSON.stringify({ token: tok, user: u }));
    await loadProfile(u.id, tok);
    setScreen('dashboard');
  }

  async function handleLogout() {
    try { await sb.signOut(token); } catch (e) {}
    localStorage.removeItem('teenstack_session');
    setToken(null); setUser(null); setProfile(null); setActiveProject(null);
    setScreen('landing');
    push('Вы вышли из аккаунта', 'info');
  }

  function openProject(p) {
    setActiveProject(p);
    setScreen('editor');
  }

  if (bootLoading) {
    return <div style={{ ...S.app, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Spinner /></div>;
  }

  return (
    <>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        * { box-sizing: border-box; }
        body { margin: 0; }
        input:focus { border-color: #7C3AED !important; }
        button { font-family: inherit; }
        button:active { transform: scale(0.98); }
      `}</style>
      <ToastStack toasts={toasts} />

      {screen === 'landing' && <Landing onAuth={(m) => setScreen(m)} />}

      {(screen === 'signin' || screen === 'signup') && (
        <AuthScreen mode={screen} setMode={setScreen} onSuccess={handleAuthSuccess} push={push} />
      )}

      {screen === 'dashboard' && profile && (
        <Dashboard
          token={token} user={user} profile={profile}
          onLogout={handleLogout} onOpenProject={openProject} push={push}
        />
      )}

      {screen === 'editor' && activeProject && (
        <ProjectEditor
          token={token} project={activeProject}
          onBack={() => setScreen('dashboard')}
          onUpdated={(p) => setActiveProject(p)}
          push={push}
        />
      )}
    </>
  );
}
